"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { Role } from "@/lib/roles";

export default function LoginForm({ role }: { role: Role }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const supabase = createClient();
    const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });

    if (authError || !data.user) {
      setError(authError?.message || "Invalid email or password.");
      setLoading(false);
      return;
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("role, full_name")
      .eq("id", data.user.id)
      .single();

    if (profileError || !profile) {
      await supabase.auth.signOut();
      setError("Your account profile is not configured. Please contact the administrator.");
      setLoading(false);
      return;
    }

    if (profile.role !== role) {
      await supabase.auth.signOut();
      setError(`This account is registered as ${profile.role.toUpperCase()}, not ${role.toUpperCase()}.`);
      setLoading(false);
      return;
    }

    router.push(`/dashboard/${role}`);
    router.refresh();
  }

  return (
    <form onSubmit={submit}>
      <div className="form-group">
        <label htmlFor="email">Email / Login ID</label>
        <input className="input" id="email" type="email" value={email}
          onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required />
      </div>
      <div className="form-group">
        <label htmlFor="password">Password</label>
        <input className="input" id="password" type="password" value={password}
          onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
      </div>
      {error && <div className="login-error">{error}</div>}
      <button className="btn btn-primary" style={{width:"100%", marginTop:20}} disabled={loading}>
        {loading ? "Signing in…" : `Sign in as ${role.toUpperCase()}`}
      </button>
      <a href="/" className="btn btn-outline" style={{width:"100%", marginTop:10}}>← Back to website</a>
    </form>
  );
}