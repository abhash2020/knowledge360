import { redirect, notFound } from "next/navigation";
import { ROLES, type Role } from "@/lib/roles";
import { createClient } from "@/lib/supabase/server";
import SignOutButton from "@/components/sign-out-button";

export default async function Dashboard({ params }: { params: Promise<{ role: string }> }) {
  const { role } = await params;
  if (!Object.prototype.hasOwnProperty.call(ROLES, role)) notFound();

  const selectedRole = role as Role;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login/${selectedRole}`);

  const { data: profile } = await supabase
    .from("profiles")
    .select("role, full_name, branch_name")
    .eq("id", user.id)
    .single();

  if (!profile || profile.role !== selectedRole) {
    redirect(`/login/${selectedRole}`);
  }

  return (
    <main className="dashboard">
      <nav className="dash-nav">
        <div className="container dash-inner">
          <a href="/" className="brand"><span className="brand-mark">K</span><span>KNOWLEDGE 360<small>PORTAL</small></span></a>
          <SignOutButton />
        </div>
      </nav>
      <div className="container dash-body">
        <span className="role-pill">{ROLES[selectedRole].icon} {ROLES[selectedRole].label}</span>
        <h1 style={{fontSize:40, margin:"12px 0 4px"}}>Hello, {profile.full_name || "Knowledge 360 User"} 👋</h1>
        <p className="muted">{profile.branch_name || "Knowledge 360"} • Your role-based dashboard</p>

        <div className="dash-grid">
          <div className="dash-box"><span className="muted">Today</span><div className="num">08</div><span className="muted">Activities</span></div>
          <div className="dash-box"><span className="muted">Attendance</span><div className="num">92%</div><span className="muted">Current overview</span></div>
          <div className="dash-box"><span className="muted">Tests</span><div className="num">18</div><span className="muted">Recorded</span></div>
          <div className="dash-box"><span className="muted">Notifications</span><div className="num">04</div><span className="muted">Need attention</span></div>
        </div>

        <div className="quick-grid">
          <div className="quick">
            <h3>Portal modules</h3>
            <ul>
              {selectedRole === "student" && <><li>Study Material & DPP</li><li>Attendance</li><li>Test Results & Performance</li><li>Fees & Payment History</li></>}
              {selectedRole === "teacher" && <><li>My Classes & Timetable</li><li>Attendance & Marks Feeding</li><li>DPP / Worksheet Upload</li><li>Student Performance</li></>}
              {selectedRole === "br" && <><li>Admissions & Enquiries</li><li>Branch Attendance</li><li>Fees Register</li><li>Class / Test Schedule</li></>}
              {selectedRole === "admin" && <><li>User & Role Management</li><li>Branches & Staff</li><li>Academic Management</li><li>Fees & Reports</li></>}
            </ul>
          </div>
          <div className="quick">
            <h3>Next development step</h3>
            <p className="muted" style={{lineHeight:1.7}}>
              Connect these cards to your Supabase tables and add CRUD pages for students,
              teachers, batches, attendance, marks, study material, fees and reports.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}