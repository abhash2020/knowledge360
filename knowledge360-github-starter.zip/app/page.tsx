import Link from "next/link";
import { ROLES } from "@/lib/roles";

export default function Home() {
  return (
    <>
      <nav className="nav">
        <div className="container nav-inner">
          <Link href="/" className="brand">
            <span className="brand-mark">K</span>
            <span>KNOWLEDGE 360<small>A STEP TOWARDS SUCCESS</small></span>
          </Link>
          <div className="nav-links">
            <a href="#programs">Programs</a>
            <a href="#features">Features</a>
            <a href="#portal">Student Portal</a>
            <a href="#contact">Contact</a>
          </div>
          <Link className="btn btn-primary" href="/login/student">Login Portal</Link>
        </div>
      </nav>

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <span className="eyebrow">⭐ Learning • Testing • Progress</span>
              <h1>Build your future with <span>Knowledge 360.</span></h1>
              <p>
                A modern coaching platform for students, teachers, branch representatives
                and administrators — bringing academics and institute operations together.
              </p>
              <div className="hero-actions">
                <Link className="btn btn-primary" href="/login/student">Student Login →</Link>
                <Link className="btn btn-outline" href="#portal">Explore Portal</Link>
              </div>
            </div>

            <div className="hero-card">
              <div className="hero-card-top">
                <div>
                  <b>Knowledge 360 Portal</b>
                  <div className="muted" style={{fontSize:12, marginTop:4}}>Academic progress at a glance</div>
                </div>
                <span className="role-pill">Live Dashboard</span>
              </div>
              <div className="dashboard-mini">
                <div className="dashboard-head"><b>Student Overview</b><span>2026–27</span></div>
                <div className="stats">
                  <div className="stat"><b>92%</b><span>Attendance</span></div>
                  <div className="stat"><b>86%</b><span>Test Average</span></div>
                  <div className="stat"><b>18</b><span>Tests Taken</span></div>
                </div>
                <div style={{padding:"4px 15px 18px"}}>
                  <span style={{fontSize:12,fontWeight:800}}>Overall Progress</span>
                  <div className="progress"><i /></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="portal">
          <div className="container">
            <div className="section-head">
              <h2>One institute. Four powerful portals.</h2>
              <p>Each login gets a focused dashboard designed around the responsibilities of that role.</p>
            </div>
            <div className="roles">
              {(Object.entries(ROLES) as [keyof typeof ROLES, typeof ROLES[keyof typeof ROLES]][]).map(([key, role]) => (
                <div className="role-card" key={key}>
                  <div className="role-icon">{role.icon}</div>
                  <h3>{role.label}</h3>
                  <p>{role.description}</p>
                  <Link className="btn btn-outline" style={{width:"100%"}} href={`/login/${key}`}>
                    Open {role.label}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="features" style={{background:"#eef5ff"}}>
          <div className="container">
            <div className="section-head">
              <h2>Made for a real coaching institute</h2>
              <p>Start with the core portal and expand it into your complete Knowledge 360 ERP.</p>
            </div>
            <div className="feature-grid">
              <div className="feature"><b>📚 Study Material</b><p>Chapter notes, booklets, DPPs, worksheets and digital resources.</p></div>
              <div className="feature"><b>📝 Tests & Results</b><p>Schedule tests, enter marks and give students a clear performance view.</p></div>
              <div className="feature"><b>🕒 Attendance</b><p>Track attendance and create a reliable academic record for students and parents.</p></div>
              <div className="feature"><b>💰 Fees Management</b><p>Branch-level fee records, dues and payment history for authorized staff.</p></div>
              <div className="feature"><b>👥 Staff Management</b><p>Teacher profiles, class allocation and academic responsibilities.</p></div>
              <div className="feature"><b>📊 Reports</b><p>Use dashboards to monitor admissions, attendance, tests and overall performance.</p></div>
            </div>
          </div>
        </section>

        <section className="section" id="programs">
          <div className="container">
            <div className="cta">
              <div>
                <h2>Ready to take Knowledge 360 online?</h2>
                <p>Connect the portal to Supabase and start adding real students, teachers and branches.</p>
              </div>
              <Link className="btn btn-gold" href="/login/admin">Admin Portal →</Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer" id="contact">
        <div className="container footer-inner">
          <span>© {new Date().getFullYear()} Knowledge 360. A Step Towards Success.</span>
          <span>Kanpur • CBSE • ICSE • Academic & Competitive Preparation</span>
        </div>
      </footer>
    </>
  );
}