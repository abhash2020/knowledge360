import { notFound } from "next/navigation";
import { ROLES, type Role } from "@/lib/roles";
import LoginForm from "@/components/login-form";

export default async function LoginPage({ params }: { params: Promise<{ role: string }> }) {
  const { role } = await params;
  if (!Object.prototype.hasOwnProperty.call(ROLES, role)) notFound();

  const selectedRole = role as Role;
  return (
    <main className="login-page">
      <section className="login-brand">
        <a href="/" className="brand" style={{color:"white"}}>
          <span className="brand-mark" style={{background:"rgba(255,255,255,.15)"}}>K</span>
          <span>KNOWLEDGE 360<small style={{color:"#bfdbfe"}}>A STEP TOWARDS SUCCESS</small></span>
        </a>
        <div>
          <span className="role-pill">{ROLES[selectedRole].icon} {ROLES[selectedRole].label}</span>
          <h1>Welcome back.</h1>
          <p>{ROLES[selectedRole].description}</p>
        </div>
      </section>
      <section className="login-form-wrap">
        <div className="login-card">
          <h2>{ROLES[selectedRole].label}</h2>
          <p className="muted">Sign in to your Knowledge 360 account.</p>
          <LoginForm role={selectedRole} />
        </div>
      </section>
    </main>
  );
}