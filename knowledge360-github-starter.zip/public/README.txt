Put the official Knowledge 360 logo, branch photos and favicon in this folder later.
