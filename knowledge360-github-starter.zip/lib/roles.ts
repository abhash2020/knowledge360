export const ROLES = {
  student: {
    label: "Student Login",
    icon: "🎓",
    description: "View classes, study material, homework, attendance, tests and results.",
  },
  teacher: {
    label: "Teacher Login",
    icon: "👨‍🏫",
    description: "Manage classes, attendance, marks, DPPs, worksheets and student progress.",
  },
  br: {
    label: "BR Login",
    icon: "🏢",
    description: "Manage branch enquiries, admissions, fees, schedules and branch operations.",
  },
  admin: {
    label: "Admin Login",
    icon: "⚙️",
    description: "Full institute control over users, branches, academics, fees and reports.",
  },
} as const;

export type Role = keyof typeof ROLES;