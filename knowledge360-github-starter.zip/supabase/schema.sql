-- Knowledge 360 database starter
-- Run this in Supabase SQL Editor.

create type public.user_role as enum ('student', 'teacher', 'br', 'admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role public.user_role not null default 'student',
  branch_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- A user can read their own profile.
create policy "profiles_select_own"
on public.profiles for select
to authenticated
using (auth.uid() = id);

-- Admin can read every profile.
create policy "profiles_select_admin"
on public.profiles for select
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);

-- Admin can insert/update/delete profiles.
create policy "profiles_admin_insert"
on public.profiles for insert
to authenticated
with check (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);

create policy "profiles_admin_update"
on public.profiles for update
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
)
with check (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);

create policy "profiles_admin_delete"
on public.profiles for delete
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  )
);

-- Automatically create a profile when a new auth user is created.
-- New accounts start as students; an admin can change the role afterward.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', 'New User'));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Example future tables:
-- students, teachers, branches, batches, attendance, tests, marks,
-- study_material, fees, enquiries, notices, timetable, etc.
