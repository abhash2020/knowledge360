# Knowledge 360 — Coaching Institute Portal

A GitHub-ready Next.js starter for **Knowledge 360**, with four role-based portals:

- Student Login
- Teacher Login
- BR (Branch Representative) Login
- Admin Login

The public website is designed as a modern coaching-institute landing page and the portal is ready to connect to Supabase.

## Stack

- Next.js App Router
- TypeScript
- React
- Supabase Auth + Postgres
- Responsive CSS
- Role-based dashboard routing

Supabase's current Next.js guidance uses `@supabase/ssr` for cookie-based sessions in SSR frameworks such as Next.js.

## 1. Install

```bash
npm install
```

## 2. Create Supabase project

Create a project at Supabase and copy:

```text
Project URL
Publishable key
```

Create `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

## 3. Create database

Open Supabase → SQL Editor → paste and run:

```text
supabase/schema.sql
```

## 4. Create users

Create users in Supabase Authentication → Users.

The database trigger automatically creates a `profiles` row with the default role `student`.

For Teacher / BR / Admin accounts, an administrator can change the role in the `profiles` table:

```text
student
teacher
br
admin
```

For production, create an admin-management screen rather than editing roles manually.

## 5. Start

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Login pages:

```text
/login/student
/login/teacher
/login/br
/login/admin
```

Dashboard pages:

```text
/dashboard/student
/dashboard/teacher
/dashboard/br
/dashboard/admin
```

## Recommended production expansion

### Student
- Profile
- Study material
- Homework / DPP
- Attendance
- Test results
- Performance graph
- Fees
- Notices

### Teacher
- Profile
- Assigned batches
- Timetable
- Attendance feeding
- Marks feeding
- DPP / worksheet upload
- Test paper submission
- Student performance

### BR
- Enquiry management
- Admission management
- ID card management
- Biometric/attendance view
- Fees register
- Batch schedule
- Test schedule
- Marks and homework updates
- Absent-student calling list

### Admin
- All users
- Branch management
- Teacher management
- Student management
- Course/batch management
- Fees
- Attendance
- Tests
- Results
- Notices
- Reports
- Permissions

## Security

Do not put Supabase service-role keys in browser/client code.

Use Row Level Security for all institute tables. The starter schema enables RLS for `profiles`; add RLS policies to every future table.

For production, add:
- password reset
- email verification
- optional 2FA for Admin
- audit logs
- role/branch permission checks
- rate limiting
- server-side validation
- backups

## GitHub

```bash
git init
git add .
git commit -m "Initial Knowledge 360 portal"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/knowledge360.git
git push -u origin main
```

Then deploy the repository on Vercel and add the same environment variables.
